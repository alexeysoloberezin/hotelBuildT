export const nav = [
  {
    link: "#about-us",
    id: "about-us",
    name: "О нас"
  },
  {
    link: "#advantages",
    id: "advantages",
    name: "Преимущества"
  },
  {
    link: "/",
    name: "Виды станций"
  },
  {
    link: "#footer",
    id: "footer",
    name: "Контакты"
  },
]

