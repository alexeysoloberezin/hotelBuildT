import EventClient from "@/app/pgs/eventClient";

export default function Page() {
  return (
    <EventClient />
  )
}