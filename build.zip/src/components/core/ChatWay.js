'use client';

import React from 'react';

function ChatWay(props) {
  return (
    <div></div>
  );
}

export default ChatWay;