export const botToken = '7341349778:AAE48R1uvxTpIEv1qgI29nWL6aFaIVWC7_A';
export const chatId = '-1002198127861';